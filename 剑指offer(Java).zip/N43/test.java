package N43;

public class test {
    public static void main(String[] args){
        String str = "abcdefghi";
        int n = 3;
        Solution solution = new Solution();
        String res = solution.LeftRotateString(str, n);
        System.out.println(res);
    }
}
