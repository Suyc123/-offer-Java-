package N04;

public class test {
    public static void main(String[] args){
        int[] pre = {};
        int[] in = {};
        Solution solution = new Solution();
        Solution.TreeNode root = solution.reConstructBinaryTree(pre, in);
    }
}
