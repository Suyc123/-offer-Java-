package N34;

public class test {
    public static void main(String[] args){
        String str = "google";
        Solution solution = new Solution();
        int res = solution.FirstNotRepeatingChar(str);
        System.out.println(res);
    }
}
