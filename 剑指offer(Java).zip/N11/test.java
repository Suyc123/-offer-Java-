package N11;

public class test {
    public static void main(String[] args){
        int n = 10;
        Solution solution = new Solution();
        int res = solution.NumberOf1(n);
        System.out.println(res);
    }
}
