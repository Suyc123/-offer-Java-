package N49;

public class test {
    public static void main(String[] args){
        String str = "33";
        Solution solution = new Solution();
        int res = solution.StrToInt(str);
        System.out.println(res);
    }
}
