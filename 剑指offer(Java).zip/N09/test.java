package N09;

public class test {
    public static void main(String[] args){
        int target = 2;
        Solution solution = new Solution();
        int res = solution.JumpFloor(target);
        System.out.println(res);
    }
}
