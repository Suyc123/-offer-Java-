package N44;

public class test {
    public static void main(String[] args){
        String str = "   ";
        Solution solution = new Solution();
        String res = solution.ReverseSentence(str);
        System.out.println(res);

    }
}
