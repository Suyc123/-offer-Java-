package N12;

public class test {
    public static void main(String[] args){
        double base = 2.3;
        int exponent = 6;
        Solution solution = new Solution();
        double res = solution.Power1(base, exponent);
        System.out.println(res);
    }
}
