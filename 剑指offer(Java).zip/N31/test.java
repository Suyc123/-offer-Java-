package N31;

public class test {
    public static void main(String[] args){
        int n = 100;
        Solution solution = new Solution();
        int res = solution.NumberOf1Between1AndN_Solution(n);
        System.out.println(res);
    }
}
