package N08;

public class test {
    public static void main(String[] args){
        int target = 4;
        Solution solution = new Solution();
        int res = solution.JumpFloor(target);
        System.out.println(res);
    }
}
