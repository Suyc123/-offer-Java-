package N46;

public class test {
    public static void main(String[] args){
        int n = 5, m = 3;
        Solution solution = new Solution();
        int res = solution.LastRemaining_Solution(n, m);
        System.out.println(res);
    }
}
