package N15;

public class test {
    public static void main(String[] args){
        Solution solution = new Solution();
    }
}
