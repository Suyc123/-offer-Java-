package N07;

public class test {
    public static void main(String[] args){
        int n = 3;
        Solution solution = new Solution();
        int res = solution.Fibonacci(n);
        System.out.println(res);
    }
}
