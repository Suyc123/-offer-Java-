package N02;

public class test {
    public static void main(String[] args){
        StringBuffer str = new StringBuffer("we are happy");
        Solution solution = new Solution();
        String res = solution.replaceSpace(str);
        System.out.println(res);
    }
}
